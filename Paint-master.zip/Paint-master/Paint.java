/**
 * Jaired Jawed
 * Dec 10, 2017
 * Paint.java
 */

public class Paint {
  public static void main(String[] args) {
    DrawFrame frame = new DrawFrame();
  }
}
